#!/bin/sh

for arg in "$*"
do 
    echo "$arg"
    tmp=$arg
    name=${tmp##*/}
    sym_file=${name}.sym
    echo "$sym_file"

    ../tools/dump_syms $arg > $sym_file
    read line < $sym_file
    echo "$line"

    OLD_IFS="$IFS"
    IFS=" "
    array=($line)
    IFS="$OLD_IFS"
    dir=./symbols/${array[4]}/${array[3]}
    echo "$dir"

    mkdir -p $dir
    mv $sym_file $dir
done