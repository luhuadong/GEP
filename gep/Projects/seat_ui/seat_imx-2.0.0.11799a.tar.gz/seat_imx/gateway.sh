#!/bin/sh
#route del default gw 192.168.3.101
#route add default gw 192.168.3.101
